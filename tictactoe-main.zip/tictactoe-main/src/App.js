import "./App.css";
import TicTacToe from "./TicTacToe";
const App = () => {
  return (
    <div className="App">
      <TicTacToe />
    </div>
  );
};
export default App;